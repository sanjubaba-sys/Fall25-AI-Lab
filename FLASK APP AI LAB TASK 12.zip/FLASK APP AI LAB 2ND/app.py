from flask import Flask, render_template, request
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

app = Flask(__name__)

# Load data
df = pd.read_csv("CAR DETAILS FROM CAR DEKHO.csv")
df = pd.get_dummies(df, drop_first=True)

X = df.drop("selling_price", axis=1)
y = df["selling_price"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestRegressor(n_estimators=300, random_state=42)
model.fit(X_train, y_train)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        year = int(request.form["year"])
        present_price = float(request.form["present_price"])
        kms_driven = int(request.form["kms_driven"])
        owner = int(request.form["owner"])
        fuel = request.form["fuel"]
        seller = request.form["seller"]
        transmission = request.form["transmission"]

        input_data = {
            'year': year,
            'present_price': present_price,
            'kms_driven': kms_driven,
            'owner': owner,
            'fuel_Diesel': 1 if fuel == "Diesel" else 0,
            'fuel_Petrol': 1 if fuel == "Petrol" else 0,
            'seller_type_Individual': 1 if seller == "Individual" else 0,
            'transmission_Manual': 1 if transmission == "Manual" else 0,
        }

        # fill missing columns
        for col in X_train.columns:
            if col not in input_data:
                input_data[col] = 0

        final_data = pd.DataFrame([input_data])[X_train.columns]

        output = model.predict(final_data)[0]
        output = round(output, 2)

        return render_template("result.html", price=output)

    except Exception as e:
        return str(e)

if __name__ == "__main__":
    app.run(debug=True)
